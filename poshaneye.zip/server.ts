import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "10mb" }));

// Lazy Gemini client initialization
function getGeminiClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

// API Routes
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", appName: "PoshanEye" });
});

// PoshanAi Assistant Chat / Voice Endpoint
app.post("/api/poshan-ai", async (req, res) => {
  try {
    const { message, childContext } = req.body;
    const ai = getGeminiClient();

    if (!ai) {
      // Fallback friendly response if API key is not yet set
      return res.json({
        reply: `Aarav is tracking nicely! For "${message}", I recommend offering a balanced mix of whole grains, soft proteins like lentils or curd, and fresh fruits. Keep portion sizes small and encouraging!`,
        source: "fallback",
      });
    }

    const contextStr = childContext
      ? `Child context: Name: ${childContext.name || "Aarav"}, Age: ${childContext.ageYears || 2}y ${childContext.ageMonths || 3}m, Weight: ${childContext.weight || 14.2}kg, Height: ${childContext.height || 92.5}cm.`
      : "Child context: Name Aarav, Age 2y 3m, Weight 14.2kg, Height 92.5cm, WHO status On Track.";

    const systemInstruction = `You are PoshanAi, an empathetic, expert pediatric nutritionist and child growth assistant for parents.
Your voice is warm, reassuring, evidence-based, and concise (2-4 sentences max per answer).
Always provide actionable, gentle advice following WHO child growth standards and pediatric nutrition best practices.
Never give dangerous medical prescriptions.
${contextStr}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: message,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    res.json({ reply: response.text || "I'm here to help with Aarav's growth and nutrition!" });
  } catch (error: any) {
    console.error("PoshanAi Error:", error);
    res.status(500).json({
      error: "Failed to get response from PoshanAi",
      reply: "I'm having a little trouble connecting right now, but Aarav's growth trends look steady and healthy! Feel free to try asking again in a moment.",
    });
  }
});

// AI Growth Calculation and WHO Insights
app.post("/api/growth-calc", async (req, res) => {
  try {
    const { gender, ageYears, ageMonths, weight, height } = req.body;
    const totalMonths = (Number(ageYears) || 0) * 12 + (Number(ageMonths) || 0);
    const weightNum = Number(weight) || 14.2;
    const heightNum = Number(height) || 92.5;

    // Simple deterministic WHO reference calculation
    const bmi = (weightNum / Math.pow(heightNum / 100, 2)).toFixed(1);
    
    // Estimate percentile based on standard WHO charts for toddler
    let percentile = 50;
    if (totalMonths >= 24 && totalMonths <= 36) {
      if (weightNum > 13.5 && weightNum < 15.5) percentile = 75;
      else if (weightNum >= 15.5) percentile = 85;
      else if (weightNum <= 12.0) percentile = 30;
    }

    const ai = getGeminiClient();
    let advice = "Aarav is right on track. Weight and height are well balanced according to WHO growth curves.";

    if (ai) {
      try {
        const prompt = `Analyze growth for a ${gender} child aged ${ageYears}y ${ageMonths}m with weight ${weightNum}kg and height ${heightNum}cm (BMI ${bmi}, approx ${percentile}th percentile).
Provide 2 short reassuring sentences explaining what this means to the parent and 2 practical nutrition tips. Return plain text only.`;
        const aiRes = await ai.models.generateContent({
          model: "gemini-3.6-flash",
          contents: prompt,
        });
        if (aiRes.text) advice = aiRes.text.trim();
      } catch (err) {
        console.warn("Gemini growth advice fallback:", err);
      }
    }

    res.json({
      gender,
      totalMonths,
      weight: weightNum,
      height: heightNum,
      bmi,
      percentile: `${percentile}th`,
      status: "On Track",
      statusHeading: "Aarav is thriving!",
      advice,
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// AI Scan Image Analysis Endpoint
app.post("/api/analyze-scan", async (req, res) => {
  try {
    const { imageBase64 } = req.body;
    const ai = getGeminiClient();

    let analysis = {
      status: "Healthy",
      heading: "Aarav is growing normally",
      timestamp: "Today at 10:42 AM",
      measurements: {
        weight: "14.2",
        height: "94.5",
        muac: "15.0",
        muacStatus: "Healthy",
      },
      explanation:
        "Aarav is right on track. His weight and height are perfectly balanced, and his arm circumference (MUAC) shows he is getting plenty of the right nutrients. Keep doing what you're doing!",
    };

    if (ai && imageBase64) {
      try {
        const cleanBase64 = imageBase64.replace(/^data:image\/\w+;base64,/, "");
        const response = await ai.models.generateContent({
          model: "gemini-3.6-flash",
          contents: {
            parts: [
              {
                inlineData: {
                  data: cleanBase64,
                  mimeType: "image/jpeg",
                },
              },
              {
                text: "Perform a pediatric growth posture and nutrition scan observation. Provide a concise summary on whether the child appears energetic and healthy, estimated weight/height/MUAC consistency. Return a 2 sentence parent summary.",
              },
            ],
          },
        });
        if (response.text) {
          analysis.explanation = response.text.trim();
        }
      } catch (e) {
        console.warn("Scan image analysis AI fallback used", e);
      }
    }

    res.json(analysis);
  } catch (error: any) {
    res.status(500).json({ error: "Scan analysis failed" });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`PoshanEye server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
