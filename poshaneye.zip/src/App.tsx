import React, { useState } from "react";
import { NavTab, ChildProfile, VitalRecord } from "./types";
import { LivingBackgroundShader } from "./components/LivingBackgroundShader";
import { Header } from "./components/Header";
import { BottomNav } from "./components/BottomNav";
import { HomeView } from "./components/HomeView";
import { GrowthView } from "./components/GrowthView";
import { AiScanView } from "./components/AiScanView";
import { NutritionView } from "./components/NutritionView";
import { PoshanAiView } from "./components/PoshanAiView";
import { ProfileView } from "./components/ProfileView";

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>("home");

  const [child, setChild] = useState<ChildProfile>({
    name: "Aarav",
    parentNames: "Sarah & Leo",
    accountType: "Premium Account",
    gender: "boy",
    ageYears: 2,
    ageMonths: 3,
    avatarUrl:
      "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=120&q=80",
    status: "On Track",
    statusDescription: "Following a healthy growth path compared to WHO standards.",
  });

  const [vitals, setVitals] = useState<VitalRecord>({
    weight: 14.2,
    height: 92.5,
    muac: 14.5,
    date: "Updated 2 days ago",
    bmi: 16.2,
    percentile: "75th",
  });

  const getPageTitle = (): string => {
    switch (activeTab) {
      case "home":
        return "Home";
      case "growth-tracking":
        return "Growth Tracking";
      case "ai-scan":
        return "Ai Scan";
      case "nutrition-plan":
        return "Nutrition Plan";
      case "child-profile":
        return "Child Profile";
      case "poshan-ai":
        return "PoshanAi Voice";
      default:
        return "PoshanEye";
    }
  };

  const handleAddVitalRecord = (record: VitalRecord) => {
    setVitals(record);
  };

  return (
    <div className="min-h-screen bg-[#faf9f5] text-[#1b1c1a] font-['Geist',sans-serif] relative flex flex-col selection:bg-[#cae8c9]">
      {/* Living WebGL Canvas Shader Background */}
      <LivingBackgroundShader opacity={0.35} />

      {/* Persistent Header */}
      <Header
        title={getPageTitle()}
        activeTab={activeTab}
        onProfileClick={() => setActiveTab("child-profile")}
        showBack={activeTab !== "home"}
        onBackClick={() => setActiveTab("home")}
      />

      {/* Main Content Area */}
      <main className="flex-1 w-full max-w-lg mx-auto overflow-x-hidden">
        {activeTab === "home" && (
          <HomeView
            child={child}
            vitals={vitals}
            onNavigate={(tab) => setActiveTab(tab)}
          />
        )}

        {activeTab === "growth-tracking" && (
          <GrowthView
            child={child}
            vitals={vitals}
            onAddVitalRecord={handleAddVitalRecord}
          />
        )}

        {activeTab === "ai-scan" && (
          <AiScanView
            child={child}
            vitals={vitals}
            onNavigate={(tab) => setActiveTab(tab)}
          />
        )}

        {activeTab === "nutrition-plan" && (
          <NutritionView child={child} />
        )}

        {activeTab === "poshan-ai" && (
          <PoshanAiView child={child} vitals={vitals} />
        )}

        {activeTab === "child-profile" && (
          <ProfileView child={child} vitals={vitals} />
        )}
      </main>

      {/* Fixed Bottom Navigation */}
      <BottomNav
        activeTab={activeTab}
        onTabChange={(tab) => setActiveTab(tab)}
      />
    </div>
  );
}
