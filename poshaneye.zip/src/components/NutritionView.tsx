import React, { useState } from "react";
import { ChildProfile, MealItem } from "../types";
import { Sun, SunMedium, Apple, Moon, Wheat, Zap, Dumbbell, Flame, Sparkles, Leaf, RefreshCw, Lightbulb } from "lucide-react";

interface NutritionViewProps {
  child: ChildProfile;
}

const defaultMeals: MealItem[] = [
  {
    id: "m1",
    mealType: "Breakfast",
    time: "8:00 AM",
    title: "Oatmeal with mashed bananas",
    icon: "sun",
    tags: [
      { label: "Fiber", icon: "wheat", bgClass: "bg-[#cae8c9]", textClass: "text-[#4f6951]" },
      { label: "Energy", icon: "zap", bgClass: "bg-[#cae8c9]", textClass: "text-[#4f6951]" },
    ],
  },
  {
    id: "m2",
    mealType: "Lunch",
    time: "12:30 PM",
    title: "Soft lentil soup (Dal) with mashed rice",
    icon: "sun-medium",
    tags: [
      { label: "Protein", icon: "dumbbell", bgClass: "bg-[#b0cdbb]", textClass: "text-[#324c3e]" },
      { label: "Iron", icon: "flame", bgClass: "bg-[#b0cdbb]", textClass: "text-[#324c3e]" },
    ],
  },
  {
    id: "m3",
    mealType: "Afternoon Snack",
    time: "3:30 PM",
    title: "Thinly sliced apples or pureed fruit",
    icon: "apple",
    tags: [
      { label: "Vitamins", icon: "sparkles", bgClass: "bg-[#bfc9bf]", textClass: "text-[#404941]" },
    ],
  },
  {
    id: "m4",
    mealType: "Dinner",
    time: "7:00 PM",
    title: "Steamed vegetables and quinoa porridge",
    icon: "moon",
    tags: [
      { label: "Digestion", icon: "leaf", bgClass: "bg-[#cae8c9]", textClass: "text-[#4f6951]" },
      { label: "Sleep Aid", icon: "moon", bgClass: "bg-[#cae8c9]", textClass: "text-[#4f6951]" },
    ],
  },
];

export const NutritionView: React.FC<NutritionViewProps> = ({ child }) => {
  const [meals, setMeals] = useState<MealItem[]>(defaultMeals);
  const [swappingId, setSwappingId] = useState<string | null>(null);

  const handleSwapMeal = (mealId: string) => {
    setSwappingId(mealId);
    setTimeout(() => {
      setMeals((prev) =>
        prev.map((m) => {
          if (m.id !== mealId) return m;
          if (m.mealType === "Breakfast") {
            return { ...m, title: "Warm ragi porridge with grated apples & almonds" };
          } else if (m.mealType === "Lunch") {
            return { ...m, title: "Mashed khichdi with ghee and steamed carrots" };
          } else if (m.mealType === "Afternoon Snack") {
            return { ...m, title: "Steamed sweet potato sticks with curd dip" };
          } else {
            return { ...m, title: "Soft pumpkin soup with whole wheat mini roti" };
          }
        })
      );
      setSwappingId(null);
    }, 800);
  };

  const renderMealIcon = (icon: string) => {
    switch (icon) {
      case "sun":
        return <Sun className="w-5 h-5 text-[#4f6951]" />;
      case "sun-medium":
        return <SunMedium className="w-5 h-5 text-[#4f6951]" />;
      case "apple":
        return <Apple className="w-5 h-5 text-[#4f6951]" />;
      case "moon":
      default:
        return <Moon className="w-5 h-5 text-[#4f6951]" />;
    }
  };

  const renderTagIcon = (icon: string) => {
    switch (icon) {
      case "wheat":
        return <Wheat className="w-3.5 h-3.5" />;
      case "zap":
        return <Zap className="w-3.5 h-3.5" />;
      case "dumbbell":
        return <Dumbbell className="w-3.5 h-3.5" />;
      case "flame":
        return <Flame className="w-3.5 h-3.5" />;
      case "sparkles":
        return <Sparkles className="w-3.5 h-3.5" />;
      case "leaf":
        return <Leaf className="w-3.5 h-3.5" />;
      case "moon":
      default:
        return <Moon className="w-3.5 h-3.5" />;
    }
  };

  return (
    <div className="flex flex-col w-full relative pt-20 pb-32 px-5 max-w-lg mx-auto">
      <h1 className="text-3xl font-bold text-[#173124] tracking-tight mb-2">
        {child.name}'s Nutrition Plan
      </h1>
      <p className="text-sm text-[#424844] mb-8 leading-relaxed">
        Here is a gentle, nourishing meal guide for today. Feel free to swap items based on what {child.name} is in the mood for.
      </p>

      {/* Timeline List */}
      <div className="relative pl-12 space-y-6 before:content-[''] before:absolute before:left-5 before:top-4 before:bottom-4 before:w-[2px] before:bg-[#bfc9bf]">
        {meals.map((meal) => (
          <div key={meal.id} className="relative">
            <div className="absolute -left-12 top-1 w-10 h-10 bg-[#cae8c9] rounded-full flex items-center justify-center shadow-xs z-10">
              {renderMealIcon(meal.icon)}
            </div>

            <div className="bg-white p-5 rounded-2xl shadow-xs border border-[#e3e2df]/80">
              <div className="flex justify-between items-start mb-1">
                <h2 className="text-lg font-bold text-[#173124]">{meal.mealType}</h2>
                <span className="text-xs font-semibold text-[#424844] bg-[#efeeea] px-2.5 py-1 rounded-md">
                  {meal.time}
                </span>
              </div>
              <p className="text-sm text-[#1b1c1a] mb-3 font-medium leading-normal">{meal.title}</p>

              <div className="flex items-center justify-between flex-wrap gap-2 pt-1 border-t border-[#efeeea]">
                <div className="flex flex-wrap gap-1.5">
                  {meal.tags.map((tag, idx) => (
                    <span
                      key={idx}
                      className={`text-xs font-semibold ${tag.textClass} ${tag.bgClass} px-3 py-1 rounded-full flex items-center gap-1`}
                    >
                      {renderTagIcon(tag.icon)}
                      {tag.label}
                    </span>
                  ))}
                </div>

                <button
                  onClick={() => handleSwapMeal(meal.id)}
                  disabled={swappingId === meal.id}
                  className="text-xs font-semibold text-[#173124] hover:underline flex items-center gap-1 active:scale-95"
                >
                  <RefreshCw
                    className={`w-3.5 h-3.5 ${swappingId === meal.id ? "animate-spin" : ""}`}
                  />
                  {swappingId === meal.id ? "Swapping..." : "Swap Option"}
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-8 p-5 bg-[#f4f4f0] rounded-2xl shadow-xs border border-[#e3e2df] flex items-start gap-4">
        <Lightbulb className="w-7 h-7 text-[#173124] shrink-0 mt-0.5" />
        <div>
          <h3 className="font-bold text-[#173124] text-base mb-1">A quick tip</h3>
          <p className="text-xs text-[#424844] leading-relaxed">
            Remember to keep portions small and introduce one new food at a time to monitor for any sensitivities.
          </p>
        </div>
      </div>
    </div>
  );
};
