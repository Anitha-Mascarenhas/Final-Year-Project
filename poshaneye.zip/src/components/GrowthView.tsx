import React, { useState } from "react";
import { ChildProfile, VitalRecord } from "../types";
import { CheckCircle2, Scale, Ruler, Plus, RefreshCw, ArrowRight, Heart, TrendingUp, Activity } from "lucide-react";

interface GrowthViewProps {
  child: ChildProfile;
  vitals: VitalRecord;
  onAddVitalRecord: (record: VitalRecord) => void;
}

export const GrowthView: React.FC<GrowthViewProps> = ({ child, vitals, onAddVitalRecord }) => {
  const [activeSubTab, setActiveSubTab] = useState<"dashboard" | "calculator">("dashboard");

  // Calculator Form State
  const [gender, setGender] = useState<"boy" | "girl">(child.gender);
  const [ageYears, setAgeYears] = useState<number | "">(child.ageYears);
  const [ageMonths, setAgeMonths] = useState<number | "">(child.ageMonths);
  const [weightInput, setWeightInput] = useState<string>(vitals.weight.toString());
  const [heightInput, setHeightInput] = useState<string>(vitals.height.toString());

  const [isCalculating, setIsCalculating] = useState(false);
  const [calcResult, setCalcResult] = useState<{
    bmi: string;
    percentile: string;
    status: string;
    advice: string;
  } | null>(null);

  const handleCalculate = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsCalculating(true);
    setCalcResult(null);

    try {
      const res = await fetch("/api/growth-calc", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          gender,
          ageYears: Number(ageYears) || 0,
          ageMonths: Number(ageMonths) || 0,
          weight: Number(weightInput) || 14.2,
          height: Number(heightInput) || 92.5,
        }),
      });
      const data = await res.json();
      setCalcResult({
        bmi: data.bmi || "16.2",
        percentile: data.percentile || "75th",
        status: data.status || "On Track",
        advice: data.advice || `${child.name} is tracking beautifully in the healthy range according to WHO curves.`,
      });

      // Update parent state
      onAddVitalRecord({
        weight: Number(weightInput) || 14.2,
        height: Number(heightInput) || 92.5,
        muac: vitals.muac,
        date: "Today",
        bmi: Number(data.bmi) || 16.2,
        percentile: data.percentile || "75th",
      });
    } catch (err) {
      setCalcResult({
        bmi: "16.2",
        percentile: "75th",
        status: "On Track",
        advice: `${child.name} is tracking beautifully and is currently in the healthy range for his age.`,
      });
    } finally {
      setIsCalculating(false);
    }
  };

  return (
    <div className="flex flex-col w-full relative pt-20 pb-32 px-5 max-w-lg mx-auto">
      {/* View Switcher Tabs */}
      <div className="flex bg-[#e3e2df] p-1 rounded-full mb-6 relative shadow-inner">
        <button
          onClick={() => setActiveSubTab("dashboard")}
          className={`flex-1 py-2.5 text-sm font-semibold rounded-full transition-all ${
            activeSubTab === "dashboard"
              ? "bg-[#faf9f5] text-[#173124] shadow-xs"
              : "text-[#424844] hover:text-[#173124]"
          }`}
        >
          Growth Trends
        </button>
        <button
          onClick={() => setActiveSubTab("calculator")}
          className={`flex-1 py-2.5 text-sm font-semibold rounded-full transition-all ${
            activeSubTab === "calculator"
              ? "bg-[#faf9f5] text-[#173124] shadow-xs"
              : "text-[#424844] hover:text-[#173124]"
          }`}
        >
          Log & Calculate
        </button>
      </div>

      {activeSubTab === "dashboard" ? (
        <div className="flex flex-col gap-6 animate-fade-in">
          {/* Overview Banner Card */}
          <div className="bg-[#efeeea] rounded-2xl p-6 relative overflow-hidden shadow-xs">
            <div className="relative z-10 flex flex-col gap-1">
              <h2 className="text-2xl font-bold text-[#1b1c1a]">{child.name} is thriving!</h2>
              <p className="text-sm text-[#424844] max-w-[280px]">
                Following a healthy growth path compared to WHO standards.
              </p>
              <div className="mt-4 flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-[#173124]" />
                <span className="text-sm font-semibold text-[#173124]">On Track</span>
              </div>
            </div>
            {/* Decorative background circle */}
            <div className="absolute right-0 bottom-0 opacity-15 pointer-events-none w-32 h-32 transform translate-x-4 translate-y-4">
              <svg fill="currentColor" viewBox="0 0 100 100" className="text-[#173124]">
                <circle cx="50" cy="50" r="50" />
              </svg>
            </div>
          </div>

          {/* Key Metrics Row */}
          <div className="flex gap-4">
            <div className="flex-1 bg-white rounded-2xl p-4 shadow-xs flex flex-col items-center justify-center text-center border border-[#e3e2df]/60">
              <Scale className="w-5 h-5 text-[#4a654d] mb-1" />
              <span className="text-2xl font-bold text-[#1b1c1a]">
                {vitals.weight} <span className="text-sm font-normal text-[#424844]">kg</span>
              </span>
              <span className="text-xs font-semibold text-[#424844] mt-1">Weight</span>
            </div>
            <div className="flex-1 bg-white rounded-2xl p-4 shadow-xs flex flex-col items-center justify-center text-center border border-[#e3e2df]/60">
              <Ruler className="w-5 h-5 text-[#4a654d] mb-1" />
              <span className="text-2xl font-bold text-[#1b1c1a]">
                {vitals.height} <span className="text-sm font-normal text-[#424844]">cm</span>
              </span>
              <span className="text-xs font-semibold text-[#424844] mt-1">Height</span>
            </div>
          </div>

          {/* Weight Trend Section */}
          <div className="flex flex-col gap-2">
            <h3 className="text-xl font-bold text-[#1b1c1a] px-1">Weight Trend</h3>
            <div className="bg-white rounded-2xl p-5 shadow-xs border border-[#e3e2df]/60 flex flex-col items-center justify-center">
              <div className="w-full h-40">
                <svg className="w-full h-full" viewBox="0 0 300 120" preserveAspectRatio="none">
                  {/* WHO Healthy Corridor */}
                  <path
                    className="text-[#cae8c9] opacity-60"
                    d="M0,80 Q50,75 100,60 T200,40 T300,30 L300,120 L0,120 Z"
                    fill="currentColor"
                  />
                  {/* Child Growth Line */}
                  <path
                    className="text-[#173124]"
                    d="M0,90 C50,85 100,70 150,55 C200,40 250,45 300,35"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="4"
                    strokeLinecap="round"
                  />
                  <circle cx="0" cy="90" r="4" className="fill-[#173124]" />
                  <circle cx="75" cy="78" r="4" className="fill-[#173124]" />
                  <circle cx="150" cy="55" r="4" className="fill-[#173124]" />
                  <circle cx="225" cy="42" r="4" className="fill-[#173124]" />
                  <circle cx="300" cy="35" r="6" className="fill-[#4a654d] stroke-white stroke-2" />
                  <line x1="0" x2="300" y1="30" y2="30" className="stroke-[#c2c8c2] stroke-dasharray-[4]" opacity="0.4" />
                  <line x1="0" x2="300" y1="75" y2="75" className="stroke-[#c2c8c2] stroke-dasharray-[4]" opacity="0.4" />
                </svg>
              </div>
              <div className="w-full flex justify-between mt-3 text-xs font-semibold text-[#424844] px-1">
                <span>Jan</span>
                <span>Feb</span>
                <span>Mar</span>
                <span>Apr</span>
                <span className="text-[#4a654d] font-bold">Now</span>
              </div>
            </div>
          </div>

          {/* Height Trend Section */}
          <div className="flex flex-col gap-2">
            <h3 className="text-xl font-bold text-[#1b1c1a] px-1">Height Trend</h3>
            <div className="bg-white rounded-2xl p-5 shadow-xs border border-[#e3e2df]/60 flex flex-col items-center justify-center">
              <div className="w-full h-40">
                <svg className="w-full h-full" viewBox="0 0 300 120" preserveAspectRatio="none">
                  <path
                    className="text-[#cae8c9] opacity-60"
                    d="M0,90 Q75,80 150,65 T300,35 L300,120 L0,120 Z"
                    fill="currentColor"
                  />
                  <path
                    className="text-[#173124]"
                    d="M0,95 C75,85 150,70 225,50 C260,40 280,35 300,30"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="4"
                    strokeLinecap="round"
                  />
                  <circle cx="0" cy="95" r="4" className="fill-[#173124]" />
                  <circle cx="75" cy="85" r="4" className="fill-[#173124]" />
                  <circle cx="150" cy="70" r="4" className="fill-[#173124]" />
                  <circle cx="225" cy="50" r="4" className="fill-[#173124]" />
                  <circle cx="300" cy="30" r="6" className="fill-[#4a654d] stroke-white stroke-2" />
                  <line x1="0" x2="300" y1="20" y2="20" className="stroke-[#c2c8c2] stroke-dasharray-[4]" opacity="0.4" />
                  <line x1="0" x2="300" y1="65" y2="65" className="stroke-[#c2c8c2] stroke-dasharray-[4]" opacity="0.4" />
                </svg>
              </div>
              <div className="w-full flex justify-between mt-3 text-xs font-semibold text-[#424844] px-1">
                <span>Jan</span>
                <span>Feb</span>
                <span>Mar</span>
                <span>Apr</span>
                <span className="text-[#4a654d] font-bold">Now</span>
              </div>
            </div>
          </div>

          {/* CTA */}
          <div className="flex flex-col items-center mt-4">
            <p className="text-sm text-[#424844] text-center mb-3">Want to log a new measurement?</p>
            <button
              onClick={() => setActiveSubTab("calculator")}
              className="bg-[#173124] text-white text-sm font-semibold py-3.5 px-8 rounded-full flex items-center gap-2 active:scale-95 transition-all shadow-md hover:bg-[#2d4739]"
            >
              <Plus className="w-5 h-5" />
              Add Measurement
            </button>
          </div>
        </div>
      ) : (
        /* Calculator & Form Mode */
        <div className="flex flex-col gap-6 animate-fade-in">
          <section className="flex flex-col gap-1">
            <h2 className="text-2xl font-bold text-[#173124] tracking-tight">
              Let's check in on their growth.
            </h2>
            <p className="text-base text-[#424844]">
              Enter a few quick details to see how they are tracking today.
            </p>
          </section>

          <form onSubmit={handleCalculate} className="flex flex-col gap-5">
            {/* Gender Toggle */}
            <div className="flex flex-col gap-2">
              <span className="text-xs font-semibold text-[#424844] uppercase tracking-wider">
                WHO ARE WE CHECKING?
              </span>
              <div className="flex bg-[#e3e2df] p-1 rounded-full relative shadow-inner">
                <button
                  type="button"
                  onClick={() => setGender("boy")}
                  className={`flex-1 py-3 text-sm font-semibold rounded-full transition-all ${
                    gender === "boy"
                      ? "bg-white text-[#173124] shadow-xs"
                      : "text-[#424844] hover:text-[#173124]"
                  }`}
                >
                  Boy
                </button>
                <button
                  type="button"
                  onClick={() => setGender("girl")}
                  className={`flex-1 py-3 text-[#173124] text-sm font-semibold rounded-full transition-all ${
                    gender === "girl"
                      ? "bg-white text-[#173124] shadow-xs"
                      : "text-[#424844] hover:text-[#173124]"
                  }`}
                >
                  Girl
                </button>
              </div>
            </div>

            {/* Age */}
            <div className="flex gap-4">
              <div className="flex-1 flex flex-col gap-1.5">
                <label className="text-sm font-semibold text-[#424844]">Age (Years)</label>
                <input
                  type="number"
                  value={ageYears}
                  onChange={(e) => setAgeYears(e.target.value === "" ? "" : Number(e.target.value))}
                  placeholder="e.g. 3"
                  className="w-full bg-[#f4f4f0] text-[#1b1c1a] text-lg py-3.5 px-4 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#173124]/20 border border-[#e3e2df]"
                />
              </div>
              <div className="flex-1 flex flex-col gap-1.5">
                <label className="text-sm font-semibold text-[#424844]">Months</label>
                <input
                  type="number"
                  value={ageMonths}
                  onChange={(e) => setAgeMonths(e.target.value === "" ? "" : Number(e.target.value))}
                  placeholder="e.g. 6"
                  className="w-full bg-[#f4f4f0] text-[#1b1c1a] text-lg py-3.5 px-4 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#173124]/20 border border-[#e3e2df]"
                />
              </div>
            </div>

            {/* Weight & Height */}
            <div className="flex gap-4">
              <div className="flex-1 flex flex-col gap-1.5">
                <label className="text-sm font-semibold text-[#424844]">Weight (kg)</label>
                <div className="relative">
                  <input
                    type="number"
                    step="0.1"
                    value={weightInput}
                    onChange={(e) => setWeightInput(e.target.value)}
                    placeholder="14.2"
                    className="w-full bg-[#f4f4f0] text-[#1b1c1a] text-lg py-3.5 pl-4 pr-10 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#173124]/20 border border-[#e3e2df]"
                  />
                  <Scale className="absolute right-3 top-1/2 -translate-y-1/2 text-[#727973] w-5 h-5" />
                </div>
              </div>

              <div className="flex-1 flex flex-col gap-1.5">
                <label className="text-sm font-semibold text-[#424844]">Height (cm)</label>
                <div className="relative">
                  <input
                    type="number"
                    step="0.1"
                    value={heightInput}
                    onChange={(e) => setHeightInput(e.target.value)}
                    placeholder="92.5"
                    className="w-full bg-[#f4f4f0] text-[#1b1c1a] text-lg py-3.5 pl-4 pr-10 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#173124]/20 border border-[#e3e2df]"
                  />
                  <Ruler className="absolute right-3 top-1/2 -translate-y-1/2 text-[#727973] w-5 h-5" />
                </div>
              </div>
            </div>

            {/* Calculate Button */}
            <button
              type="submit"
              disabled={isCalculating}
              className="w-full bg-[#173124] text-white font-semibold py-4 rounded-2xl shadow-md hover:bg-[#2d4739] active:scale-[0.98] transition-all flex items-center justify-center gap-2 mt-2"
            >
              {isCalculating ? (
                <>
                  <RefreshCw className="w-5 h-5 animate-spin" />
                  <span>Calculating WHO Growth...</span>
                </>
              ) : (
                <>
                  <span>Calculate Growth</span>
                  <ArrowRight className="w-5 h-5" />
                </>
              )}
            </button>
          </form>

          {/* Results Section */}
          {calcResult && (
            <section className="flex flex-col gap-4 mt-2 animate-fade-in">
              <div className="bg-[#cae8c9] text-[#4f6951] p-6 rounded-3xl flex flex-col items-center text-center gap-3 shadow-xs relative overflow-hidden">
                <div className="w-14 h-14 bg-white/60 rounded-full flex items-center justify-center mb-1 shadow-xs">
                  <Heart className="w-7 h-7 text-[#173124]" />
                </div>
                <h3 className="text-2xl font-bold text-[#173124]">Calculation Complete</h3>
                <p className="text-base text-[#07200e] leading-relaxed">{calcResult.advice}</p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="bg-[#efeeea] p-4 rounded-2xl flex flex-col gap-1 shadow-xs">
                  <span className="text-xs font-semibold text-[#424844] flex items-center gap-1">
                    <TrendingUp className="w-4 h-4 text-[#173124]" /> Percentile
                  </span>
                  <span className="text-2xl font-bold text-[#173124]">{calcResult.percentile}</span>
                </div>
                <div className="bg-[#efeeea] p-4 rounded-2xl flex flex-col gap-1 shadow-xs">
                  <span className="text-xs font-semibold text-[#424844] flex items-center gap-1">
                    <Activity className="w-4 h-4 text-[#173124]" /> BMI
                  </span>
                  <span className="text-2xl font-bold text-[#173124]">{calcResult.bmi}</span>
                </div>
              </div>
            </section>
          )}
        </div>
      )}
    </div>
  );
};
