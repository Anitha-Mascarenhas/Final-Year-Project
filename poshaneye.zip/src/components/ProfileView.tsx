import React, { useState } from "react";
import { ChildProfile, VitalRecord } from "../types";
import { Edit2, Baby, Bell, Sliders, ChevronRight, HelpCircle, ShieldCheck } from "lucide-react";

interface ProfileViewProps {
  child: ChildProfile;
  vitals: VitalRecord;
}

export const ProfileView: React.FC<ProfileViewProps> = ({ child, vitals }) => {
  const [showNotificationToast, setShowNotificationToast] = useState(false);
  const [toastMessage, setToastMessage] = useState("");

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setShowNotificationToast(true);
    setTimeout(() => setShowNotificationToast(false), 2500);
  };

  return (
    <div className="flex flex-col w-full relative pt-20 pb-32 px-5 max-w-lg mx-auto">
      {/* Toast Popup */}
      {showNotificationToast && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 bg-[#173124] text-white text-xs font-semibold px-4 py-2.5 rounded-full shadow-lg z-50 animate-fade-in">
          {toastMessage}
        </div>
      )}

      {/* Parent & Child Profile Header */}
      <section className="flex items-center gap-4 bg-[#efeeea] rounded-3xl p-4 mb-6 border border-[#e3e2df]">
        <div className="relative w-16 h-16 rounded-full overflow-hidden shrink-0 ring-2 ring-[#cceacc]">
          <img
            className="w-full h-full object-cover"
            src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=120&q=80"
            alt="Sarah & Aarav"
          />
        </div>
        <div className="flex flex-col flex-grow min-w-0">
          <h2 className="text-xl font-bold text-[#1b1c1a] truncate">{child.parentNames}</h2>
          <p className="text-xs text-[#424844] truncate">{child.accountType}</p>
        </div>
        <button
          onClick={() => triggerToast("Profile details updated")}
          className="w-10 h-10 rounded-full flex items-center justify-center bg-[#e9e8e4] text-[#1b1c1a] hover:bg-[#e3e2df] active:scale-95 transition-all shrink-0"
        >
          <Edit2 className="w-4 h-4" />
        </button>
      </section>

      {/* Child Overview Badge */}
      <section className="bg-[#cae8c9] text-[#07200e] rounded-2xl p-4 mb-6 flex items-center gap-4">
        <div className="w-12 h-12 rounded-full bg-white/60 flex items-center justify-center shrink-0">
          <Baby className="w-6 h-6 text-[#173124]" />
        </div>
        <div>
          <h3 className="font-bold text-base text-[#173124]">{child.name}</h3>
          <p className="text-xs text-[#4f6951]">
            {child.ageYears}y {child.ageMonths}m • {child.gender === "boy" ? "Male" : "Female"} • {child.status}
          </p>
        </div>
      </section>

      {/* Settings Groups */}
      <div className="space-y-6">
        {/* PREFERENCES */}
        <section className="space-y-2">
          <h3 className="text-xs font-semibold text-[#2d4739] uppercase tracking-widest pl-1">
            Preferences
          </h3>
          <div className="bg-[#efeeea] rounded-3xl overflow-hidden flex flex-col border border-[#e3e2df]">
            <button
              onClick={() => triggerToast("Notifications enabled")}
              className="flex items-center justify-between p-4 hover:bg-[#e9e8e4] transition-colors w-full text-left group"
            >
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-full bg-[#cae8c9] flex items-center justify-center text-[#4f6951]">
                  <Bell className="w-5 h-5" />
                </div>
                <span className="text-sm font-medium text-[#1b1c1a]">Notifications</span>
              </div>
              <ChevronRight className="w-5 h-5 text-[#727973] group-hover:text-[#173124]" />
            </button>

            <div className="h-px bg-[#e3e2df] mx-4" />

            <button
              onClick={() => triggerToast("App settings opened")}
              className="flex items-center justify-between p-4 hover:bg-[#e9e8e4] transition-colors w-full text-left group"
            >
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-full bg-[#cae8c9] flex items-center justify-center text-[#4f6951]">
                  <Sliders className="w-5 h-5" />
                </div>
                <span className="text-sm font-medium text-[#1b1c1a]">App Settings</span>
              </div>
              <ChevronRight className="w-5 h-5 text-[#727973] group-hover:text-[#173124]" />
            </button>

            <div className="h-px bg-[#e3e2df] mx-4" />

            <button
              onClick={() => triggerToast("Managing child profiles")}
              className="flex items-center justify-between p-4 hover:bg-[#e9e8e4] transition-colors w-full text-left group"
            >
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-full bg-[#cae8c9] flex items-center justify-center text-[#4f6951]">
                  <Baby className="w-5 h-5 text-[#4f6951]" />
                </div>
                <span className="text-sm font-medium text-[#1b1c1a]">Manage Profiles</span>
              </div>
              <ChevronRight className="w-5 h-5 text-[#727973] group-hover:text-[#173124]" />
            </button>
          </div>
        </section>

        {/* SUPPORT */}
        <section className="space-y-2">
          <h3 className="text-xs font-semibold text-[#2d4739] uppercase tracking-widest pl-1">
            Support
          </h3>
          <div className="bg-[#efeeea] rounded-3xl overflow-hidden flex flex-col border border-[#e3e2df]">
            <button
              onClick={() => triggerToast("Help Center loaded")}
              className="flex items-center justify-between p-4 hover:bg-[#e9e8e4] transition-colors w-full text-left group"
            >
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-full bg-[#faf9f5] flex items-center justify-center text-[#424844]">
                  <HelpCircle className="w-5 h-5" />
                </div>
                <span className="text-sm font-medium text-[#1b1c1a]">Help Center</span>
              </div>
              <ChevronRight className="w-5 h-5 text-[#727973] group-hover:text-[#173124]" />
            </button>

            <div className="h-px bg-[#e3e2df] mx-4" />

            <button
              onClick={() => triggerToast("Privacy & Security verified")}
              className="flex items-center justify-between p-4 hover:bg-[#e9e8e4] transition-colors w-full text-left group"
            >
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-full bg-[#faf9f5] flex items-center justify-center text-[#424844]">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <span className="text-sm font-medium text-[#1b1c1a]">Privacy & Security</span>
              </div>
              <ChevronRight className="w-5 h-5 text-[#727973] group-hover:text-[#173124]" />
            </button>
          </div>
        </section>
      </div>

      {/* Logout */}
      <div className="pt-8 flex justify-center pb-4">
        <button
          onClick={() => triggerToast("Signed out safely")}
          className="px-8 py-3 rounded-full border border-[#ba1a1a] text-[#ba1a1a] text-sm font-semibold hover:bg-[#ffdad6] hover:text-[#93000a] active:scale-95 transition-all"
        >
          Sign Out
        </button>
      </div>
    </div>
  );
};
