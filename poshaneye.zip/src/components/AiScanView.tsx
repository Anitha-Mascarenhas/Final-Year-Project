import React, { useState, useEffect, useRef } from "react";
import { NavTab, ChildProfile, VitalRecord } from "../types";
import { Volume2, Camera, RefreshCw, X, CheckCircle2, Utensils } from "lucide-react";

interface AiScanViewProps {
  child: ChildProfile;
  vitals: VitalRecord;
  onNavigate: (tab: NavTab) => void;
}

export const AiScanView: React.FC<AiScanViewProps> = ({ child, vitals, onNavigate }) => {
  const [scanMode, setScanMode] = useState<"camera" | "distraction" | "result">("camera");
  const [isDistractingSoundsOn, setIsDistractingSoundsOn] = useState(false);
  const [isCapturing, setIsCalculating] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const pipVideoRef = useRef<HTMLVideoElement | null>(null);

  const playSoothingSound = () => {
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) return;
      const ctx = new AudioContextClass();
      
      const notes = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6 chime
      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sine";
        osc.frequency.setValueAtTime(freq, ctx.currentTime + idx * 0.15);
        gain.gain.setValueAtTime(0.2, ctx.currentTime + idx * 0.15);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + idx * 0.15 + 0.6);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(ctx.currentTime + idx * 0.15);
        osc.stop(ctx.currentTime + idx * 0.15 + 0.6);
      });
    } catch (e) {
      console.log("Audio play error", e);
    }
  };

  useEffect(() => {
    let stream: MediaStream | null = null;
    if (scanMode === "camera" || scanMode === "distraction") {
      navigator.mediaDevices
        ?.getUserMedia({ video: { facingMode: "environment" } })
        .then((s) => {
          stream = s;
          if (videoRef.current) videoRef.current.srcObject = s;
          if (pipVideoRef.current) pipVideoRef.current.srcObject = s;
        })
        .catch(() => {
          // Camera permission denied or iframe fallback
        });
    }

    return () => {
      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
      }
    };
  }, [scanMode]);

  const handleCapture = () => {
    setIsCalculating(true);
    if (isDistractingSoundsOn) playSoothingSound();

    setTimeout(() => {
      setIsCalculating(false);
      setScanMode("result");
    }, 1200);
  };

  return (
    <div className="flex flex-col w-full relative pt-16 pb-32 min-h-screen px-4 max-w-lg mx-auto">
      {/* 1. CAMERA SCAN FRAME MODE */}
      {scanMode === "camera" && (
        <div className="flex flex-col items-center justify-between min-h-[calc(100vh-140px)] animate-fade-in relative z-10">
          {/* Top Instruction */}
          <div className="text-center pt-3">
            <h2 className="text-2xl font-semibold text-[#1b1c1a]">Let's check in on their growth</h2>
            <p className="text-sm text-[#424844] mt-1">
              Position {child.name} inside the gentle frame below.
            </p>
          </div>

          {/* Positioning Guide (Silhouette & Corner Brackets) */}
          <div className="relative w-full max-w-[300px] h-[380px] my-6 flex items-center justify-center rounded-3xl overflow-hidden shadow-inner border border-[#cceacc] bg-[#efeeea]">
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className="absolute inset-0 w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-[#faf9f5]/30 via-transparent to-[#faf9f5]/80 pointer-events-none" />

            {/* Silhouette Outline */}
            <svg
              className="w-full h-[320px] drop-shadow-md opacity-85 text-[#2d4739] z-10 animate-pulse"
              viewBox="0 0 200 400"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M100 50 C 130 50, 140 80, 140 100 C 140 130, 110 150, 100 150 C 90 150, 60 130, 60 100 C 60 80, 70 50, 100 50 Z"
                stroke="currentColor"
                strokeWidth="3.5"
                strokeDasharray="8 8"
                strokeLinecap="round"
              />
              <path
                d="M100 150 L 100 250"
                stroke="currentColor"
                strokeWidth="3.5"
                strokeDasharray="8 8"
                strokeLinecap="round"
              />
              <path
                d="M100 170 C 140 180, 160 220, 160 250"
                stroke="currentColor"
                strokeWidth="3.5"
                strokeDasharray="8 8"
                strokeLinecap="round"
              />
              <path
                d="M100 170 C 60 180, 40 220, 40 250"
                stroke="currentColor"
                strokeWidth="3.5"
                strokeDasharray="8 8"
                strokeLinecap="round"
              />
              <path
                d="M100 250 C 120 280, 130 350, 130 380"
                stroke="currentColor"
                strokeWidth="3.5"
                strokeDasharray="8 8"
                strokeLinecap="round"
              />
              <path
                d="M100 250 C 80 280, 70 350, 70 380"
                stroke="currentColor"
                strokeWidth="3.5"
                strokeDasharray="8 8"
                strokeLinecap="round"
              />
            </svg>

            {/* Corner Brackets */}
            <div className="absolute top-4 left-4 w-7 h-7 border-t-3 border-l-3 border-[#173124] rounded-tl-lg" />
            <div className="absolute top-4 right-4 w-7 h-7 border-t-3 border-r-3 border-[#173124] rounded-tr-lg" />
            <div className="absolute bottom-4 left-4 w-7 h-7 border-b-3 border-l-3 border-[#173124] rounded-bl-lg" />
            <div className="absolute bottom-4 right-4 w-7 h-7 border-b-3 border-r-3 border-[#173124] rounded-br-lg" />
          </div>

          {/* Controls */}
          <div className="flex flex-col items-center gap-4 w-full pb-6">
            <div className="flex items-center gap-3">
              <button
                onClick={() => {
                  const nextState = !isDistractingSoundsOn;
                  setIsDistractingSoundsOn(nextState);
                  if (nextState) playSoothingSound();
                }}
                className="flex items-center gap-2 bg-[#e9e8e4] px-4 py-2 rounded-full shadow-xs hover:bg-[#e3e2df] active:scale-95 transition-all"
              >
                <Volume2 className="w-4 h-4 text-[#4f6951]" />
                <span className="text-xs font-semibold text-[#424844]">Distract with sounds</span>
                <span
                  className={`w-9 h-5 rounded-full p-0.5 transition-colors ${
                    isDistractingSoundsOn ? "bg-[#173124]" : "bg-[#bfc9bf]"
                  }`}
                >
                  <div
                    className={`w-4 h-4 bg-white rounded-full transition-transform ${
                      isDistractingSoundsOn ? "translate-x-4" : "translate-x-0"
                    }`}
                  />
                </span>
              </button>

              <button
                onClick={() => setScanMode("distraction")}
                className="bg-[#cae8c9] text-[#07200e] text-xs font-semibold px-3 py-2 rounded-full shadow-xs hover:bg-[#b1ceb1] transition-all"
              >
                Mascot Mode
              </button>
            </div>

            {/* Shutter Button */}
            <div className="relative mt-2">
              <div className="absolute inset-0 bg-[#173124]/20 rounded-full blur-lg animate-pulse" />
              <button
                onClick={handleCapture}
                disabled={isCapturing}
                className="relative w-20 h-20 rounded-full bg-white shadow-lg flex items-center justify-center p-2 hover:scale-105 active:scale-95 transition-transform"
              >
                <div className="w-full h-full rounded-full bg-[#173124] flex items-center justify-center text-white">
                  {isCapturing ? (
                    <RefreshCw className="w-8 h-8 animate-spin" />
                  ) : (
                    <Camera className="w-8 h-8" />
                  )}
                </div>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 2. DISTRACTION MODE WITH ANIMATED MASCOT BIRD */}
      {scanMode === "distraction" && (
        <div className="flex flex-col items-center justify-center min-h-[calc(100vh-140px)] animate-fade-in relative">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-[#173124] tracking-tight mb-1">
              DISTRACTION MODE ON
            </h1>
            <p className="text-lg text-[#424844]">Look here, {child.name}!</p>
          </div>

          {/* Animated Bird Mascot */}
          <div
            onClick={playSoothingSound}
            className="relative w-64 h-64 mb-8 flex items-center justify-center cursor-pointer transform hover:scale-105 active:scale-95 transition-transform"
          >
            <svg
              className="w-full h-full drop-shadow-lg"
              viewBox="0 0 200 200"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M40 100 C40 40 160 40 160 100 C160 160 40 160 40 100 Z"
                fill="#cae8c9"
              />
              <circle cx="80" cy="90" r="8" fill="#062014" />
              <circle cx="120" cy="90" r="8" fill="#062014" />
              <polygon points="90,105 110,105 100,120" fill="#4a654d" />
              <path d="M30 90 Q10 110 30 130 Q50 110 30 90 Z" fill="#b0cdbb" />
              <path d="M170 90 Q190 110 170 130 Q150 110 170 90 Z" fill="#b0cdbb" />
            </svg>
            <div className="absolute inset-0 bg-[#173124]/10 rounded-full blur-2xl -z-10 animate-pulse" />
          </div>

          <p className="text-xs text-[#727973] mb-6">Tap the bird for a cheerful chime!</p>

          <button
            onClick={() => setScanMode("camera")}
            className="bg-[#e9e8e4] text-[#424844] font-semibold text-sm px-6 py-3 rounded-full flex items-center gap-2 hover:bg-[#e3e2df] transition-colors shadow-xs"
          >
            <X className="w-5 h-5" />
            Exit Distraction Mode
          </button>

          <div className="absolute bottom-4 right-2 w-24 h-32 bg-[#efeeea] rounded-xl overflow-hidden shadow-lg border-2 border-[#cceacc]">
            <video
              ref={pipVideoRef}
              autoPlay
              playsInline
              muted
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      )}

      {/* 3. SCAN RESULT MODE */}
      {scanMode === "result" && (
        <div className="flex flex-col w-full relative pt-2 animate-fade-in">
          <div className="flex justify-center mb-4">
            <div className="w-20 h-20 bg-[#cae8c9] rounded-full flex items-center justify-center shadow-xs">
              <CheckCircle2 className="w-10 h-10 text-[#07200e]" />
            </div>
          </div>

          <h1 className="text-2xl font-bold text-[#1b1c1a] text-center mb-1">
            {child.name} is growing normally
          </h1>
          <p className="text-sm text-[#424844] text-center mb-6">Last checked today at 10:42 AM</p>

          <div className="bg-[#f4f4f0] rounded-2xl p-5 mb-6 flex flex-col gap-4 border border-[#e3e2df]">
            <h2 className="text-xs font-semibold text-[#727973] uppercase tracking-wider">
              LATEST MEASUREMENTS
            </h2>

            <div className="flex justify-between items-end">
              <div className="flex flex-col">
                <span className="text-xs text-[#424844] mb-0.5">Weight</span>
                <span className="text-2xl font-bold text-[#1b1c1a]">
                  14.2 <span className="text-sm font-normal text-[#424844]">kg</span>
                </span>
              </div>
              <svg className="text-[#4a654d] opacity-70" width="50" height="24" viewBox="0 0 48 24" fill="none">
                <path d="M2 20C12 18 18 12 24 14C30 16 38 4 46 4" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
              </svg>
            </div>

            <div className="w-full h-px bg-[#c2c8c2]/40" />

            <div className="flex justify-between items-end">
              <div className="flex flex-col">
                <span className="text-xs text-[#424844] mb-0.5">Height</span>
                <span className="text-2xl font-bold text-[#1b1c1a]">
                  94.5 <span className="text-sm font-normal text-[#424844]">cm</span>
                </span>
              </div>
              <svg className="text-[#4a654d] opacity-70" width="50" height="24" viewBox="0 0 48 24" fill="none">
                <path d="M2 20C10 19 16 14 24 12C32 10 40 6 46 2" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
              </svg>
            </div>

            <div className="w-full h-px bg-[#c2c8c2]/40" />

            <div className="flex justify-between items-end">
              <div className="flex flex-col">
                <span className="text-xs text-[#424844] mb-0.5">MUAC</span>
                <span className="text-2xl font-bold text-[#1b1c1a]">
                  15.0 <span className="text-sm font-normal text-[#424844]">cm</span>
                </span>
              </div>
              <div className="px-3 py-1 bg-[#cae8c9] rounded-full flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full bg-[#4a654d]" />
                <span className="text-xs font-semibold text-[#4f6951]">Healthy</span>
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-2 mb-8">
            <h3 className="text-xs font-semibold text-[#727973] uppercase tracking-wider">
              WHAT THIS MEANS
            </h3>
            <p className="text-base text-[#1b1c1a] leading-relaxed">
              {child.name} is right on track. His weight and height are perfectly balanced, and his arm circumference shows he is getting plenty of the right nutrients. Keep doing what you're doing!
            </p>
          </div>

          <div className="flex flex-col gap-3">
            <button
              onClick={() => onNavigate("nutrition-plan")}
              className="w-full bg-[#173124] text-white font-semibold py-4 rounded-full flex items-center justify-center gap-2 hover:bg-[#2d4739] active:scale-98 transition-all"
            >
              <Utensils className="w-5 h-5" />
              View nutrition plan
            </button>
            <button
              onClick={() => setScanMode("camera")}
              className="w-full bg-transparent border-2 border-[#173124] text-[#173124] font-semibold py-3.5 rounded-full flex items-center justify-center gap-2 hover:bg-[#173124]/5 active:scale-98 transition-all"
            >
              Scan again
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
