import React from "react";
import { NavTab, ChildProfile, VitalRecord } from "../types";
import { ClipboardCheck, ArrowRight, Scan, Utensils, Mic } from "lucide-react";

interface HomeViewProps {
  child: ChildProfile;
  vitals: VitalRecord;
  onNavigate: (tab: NavTab) => void;
}

export const HomeView: React.FC<HomeViewProps> = ({ child, vitals, onNavigate }) => {
  return (
    <div className="flex flex-col w-full relative pt-20 pb-32 px-5 max-w-lg mx-auto">
      {/* Greeting Header */}
      <div className="mb-6 animate-fade-in">
        <h2 className="text-2xl font-semibold text-[#1b1c1a] tracking-tight">Good morning,</h2>
        <p className="text-lg text-[#424844] mt-1">{child.name} is doing well.</p>
      </div>

      {/* Growth Status Summary */}
      <div className="mb-8 bg-[#efeeea] rounded-2xl p-5 border border-[#e3e2df]/60">
        <div className="flex items-center gap-2 mb-2">
          <span className="w-2.5 h-2.5 rounded-full bg-[#4a654d] inline-block animate-pulse"></span>
          <span className="text-xs font-semibold uppercase tracking-wider text-[#2d4739]">
            Growth Status
          </span>
        </div>
        <div className="text-3xl font-semibold text-[#173124] tracking-tight mb-2">
          Normal Growth
        </div>
        <p className="text-sm text-[#424844] leading-relaxed">
          {child.name} remains in the healthy percentile for his age group. Keep up the great work.
        </p>
      </div>

      {/* Current Vitals Module */}
      <div className="bg-[#dbe5da] rounded-2xl p-5 mb-8 shadow-xs">
        <div className="flex justify-between items-center mb-4">
          <h3 className="font-semibold text-lg text-[#151e17]">Current Vitals</h3>
          <span className="text-xs text-[#151e17]/70 font-medium">Updated 2 days ago</span>
        </div>
        <div className="grid grid-cols-3 gap-3">
          <div className="flex flex-col items-center justify-center p-3 rounded-xl bg-white/60 backdrop-blur-xs">
            <span className="text-xs text-[#404941] font-medium mb-1">Weight</span>
            <span className="text-xl font-bold text-[#151e17]">
              {vitals.weight} <span className="text-xs font-normal">kg</span>
            </span>
          </div>
          <div className="flex flex-col items-center justify-center p-3 rounded-xl bg-white/60 backdrop-blur-xs">
            <span className="text-xs text-[#404941] font-medium mb-1">Height</span>
            <span className="text-xl font-bold text-[#151e17]">
              {vitals.height} <span className="text-xs font-normal">cm</span>
            </span>
          </div>
          <div className="flex flex-col items-center justify-center p-3 rounded-xl bg-white/60 backdrop-blur-xs">
            <span className="text-xs text-[#404941] font-medium mb-1">MUAC</span>
            <span className="text-xl font-bold text-[#151e17]">
              {vitals.muac} <span className="text-xs font-normal">cm</span>
            </span>
          </div>
        </div>
      </div>

      {/* Latest Assessment Card */}
      <div className="mb-8">
        <div className="bg-[#f4f4f0] rounded-2xl p-5 flex items-start gap-4 border border-[#e3e2df]/80">
          <div className="w-12 h-12 rounded-full bg-[#cae8c9] flex items-center justify-center shrink-0">
            <ClipboardCheck className="w-6 h-6 text-[#4f6951]" />
          </div>
          <div className="flex-1">
            <h4 className="font-semibold text-[#1b1c1a] text-base mb-1">Latest Assessment</h4>
            <p className="text-sm text-[#424844] mb-3 leading-relaxed">
              Last scan was 2 days ago. The analysis indicates healthy nutritional milestones.
            </p>
            <button
              onClick={() => onNavigate("growth-tracking")}
              className="text-sm font-semibold text-[#173124] flex items-center gap-1 hover:opacity-80 transition-opacity"
            >
              View full report <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Primary Call to Action Buttons */}
      <div className="grid grid-cols-1 gap-3">
        <button
          onClick={() => onNavigate("ai-scan")}
          className="w-full bg-[#173124] text-white font-semibold py-4 rounded-xl flex items-center justify-center gap-2 active:scale-[0.98] transition-transform shadow-md hover:bg-[#2d4739]"
        >
          <Scan className="w-5 h-5" />
          Start New Scan
        </button>

        <button
          onClick={() => onNavigate("nutrition-plan")}
          className="w-full bg-transparent border-2 border-[#173124] text-[#173124] font-semibold py-4 rounded-xl flex items-center justify-center gap-2 active:scale-[0.98] transition-transform hover:bg-[#173124]/5"
        >
          <Utensils className="w-5 h-5" />
          Nutrition Plan
        </button>

        <button
          onClick={() => onNavigate("poshan-ai")}
          className="w-full bg-[#cae8c9] text-[#07200e] font-semibold py-3.5 rounded-xl flex items-center justify-center gap-2 active:scale-[0.98] transition-transform mt-1 hover:bg-[#b1ceb1]"
        >
          <Mic className="w-5 h-5" />
          Ask PoshanAi Voice Assistant
        </button>
      </div>
    </div>
  );
};
