import React from "react";
import { NavTab } from "../types";
import { ArrowLeft } from "lucide-react";

interface HeaderProps {
  title: string;
  activeTab: NavTab;
  onProfileClick: () => void;
  onBackClick?: () => void;
  showBack?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  title,
  onProfileClick,
  onBackClick,
  showBack = false,
}) => {
  return (
    <header className="fixed top-0 w-full z-50 pt-safe bg-[#faf9f5]/60 backdrop-blur-md shadow-[0_1px_8px_rgba(0,0,0,0.04)] border-b border-[#e3e2df]/50">
      <div className="flex items-center justify-between h-16 px-5 max-w-lg mx-auto">
        <div className="flex items-center gap-2">
          {showBack ? (
            <button
              onClick={onBackClick}
              className="w-9 h-9 -ml-2 rounded-full flex items-center justify-center hover:bg-[#e9e8e4] active:scale-95 transition-all text-[#173124]"
              aria-label="Go back"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          ) : null}

          {/* PoshanEye Brand Logo SVG */}
          <div className="flex items-center gap-2">
            <svg
              className="h-7 w-auto text-[#173124]"
              viewBox="0 0 120 80"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M10 40 Q25 10 60 10 C85 10 100 25 100 35 M20 40 Q60 70 100 40"
                stroke="currentColor"
                strokeWidth="6"
                strokeLinecap="round"
              />
              <path
                d="M20 35 Q50 15 90 20 C70 35 40 45 20 35 Z"
                fill="currentColor"
                opacity="0.15"
              />
              <circle cx="60" cy="42" r="8" fill="currentColor" />
            </svg>
            <span className="font-semibold text-xl tracking-tight text-[#173124]">
              {title}
            </span>
          </div>
        </div>

        {/* Profile Avatar */}
        <button
          onClick={onProfileClick}
          className="w-9 h-9 rounded-full overflow-hidden ring-2 ring-[#cceacc] active:scale-95 transition-transform"
        >
          <img
            src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=120&q=80"
            alt="Profile Avatar"
            className="w-full h-full object-cover"
          />
        </button>
      </div>
    </header>
  );
};
